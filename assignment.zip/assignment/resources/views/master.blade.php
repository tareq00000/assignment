@include('layouts._header')
@include('layouts._messege')
@yield('content')
@include('layouts._footer')