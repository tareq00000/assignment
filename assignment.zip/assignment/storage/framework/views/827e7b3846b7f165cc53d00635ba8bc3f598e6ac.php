<?php $__env->startSection('content'); ?>	
	<div class="well">
		<div class="row">
			<div class="col-md-6">
				<a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary pull-right"><i class="fa fa-plus-circle" aria-hidden="true"></i> New</a>
			</div>
			<div class="col-md-6">
				<div class="dropdown pull-right">
					<form action="status" method="" id="statusForm">
						<select name="status" id="status">
							<option value="">All</option>
							<option <?php if(isset($_GET['status'])&& $_GET['status']=="0"): ?><?php echo e("selected"); ?><?php endif; ?> value="0">Unpublished</option>
							<option <?php if(isset($_GET['status'])&& $_GET['status']=="1"): ?><?php echo e("selected"); ?><?php endif; ?> value="1">Published</option>							
						</select>
					</form>
				</div>
			</div>
		</div>		
	</div>
	<div class="row">
		<div class="col-md-12">
			<h2>Product List</h2>
			<div class="well">
				<table class="table table-responsive table-bordered">
					<thead>
						<tr>
							<th>#</th>
							<th>Title</th>
							<th>Category</th>
							<th>Partner</th>
							<th>Price</th>
							<th>Discount</th>
							<th>status</th>
							<th>Featured</th>
							<th></th>
						</tr>
					</thead>
					<tbody>
						<?php $i=0; ?>
						<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e(++$i); ?></td>
							<td><?php echo e($product->title); ?></td>
							<td><?php echo e($product->category->category_name); ?></td>
							<td><?php echo e($product->partner->partner_name); ?></td>
							<td><?php echo e($product->price); ?></td>
							<td><?php echo e($product->discount); ?></td>
							<td>
								<?php if($product->published==1): ?>
								<i class="fa fa-check btn btn-xs btn-success" aria-hidden="true"></i>
								<?php else: ?>
								<i class="fa fa-times btn btn-xs btn-danger" aria-hidden="true"></i>
								<?php endif; ?>
							</td>
							<td>
								<?php if($product->featured==1): ?>
								<i class="fa fa-check btn btn-xs btn-success" aria-hidden="true"></i>
								<?php else: ?>
								<i class="fa fa-times btn btn-xs btn-danger" aria-hidden="true"></i>
								<?php endif; ?>
							</td>
							<td>
								<?php echo Form::open(['route' => ['products.destroy', $product->id], 'method' => 'DELETE', 'onsubmit' => 'return ConfirmDelete()']); ?>

									<a href="<?php echo e(route('products.edit',$product->id)); ?>" class="btn btn-xs btn-primary"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
									<?php echo Form::submit("Delete", ['class' => 'btn btn-danger btn-xs pull-right']); ?>

								<?php echo Form::close(); ?>

								
							</td>							
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>