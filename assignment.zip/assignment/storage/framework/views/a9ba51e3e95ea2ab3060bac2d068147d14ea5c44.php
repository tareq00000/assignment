<?php $__env->startSection('content'); ?>
<div class="row center" style="margin-top: 15px;">
	<div class="col-md-6 col-md-offset-1">
		<div class="well">
			<h2>Edit Partner</h2>
			<?php echo Form::model($partner,['route' => ['partners.update',$partner->id],'method'=>'PUT']); ?>

			

				<div class="form-group">
					<?php echo e(Form::label('partner_name', 'Partner Name:')); ?>

					<?php echo e(Form::text('partner_name', null,['class'=>'form-control', 'placeholder'=>'Insert a partner name'])); ?>

				</div>

				<div class="form-group">
					<?php echo e(Form::submit('Save Changes',['class'=>'btn btn-success'])); ?>

					<a href="<?php echo e(route('partners.index')); ?>" class="btn btn-default">Cancel</a>
				</div>
		    
			<?php echo Form::close(); ?>

		</div>
	</div>
</div>
	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>