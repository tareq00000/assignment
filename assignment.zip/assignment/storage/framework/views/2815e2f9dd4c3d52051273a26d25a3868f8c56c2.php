<?php $__env->startSection('content'); ?>
	<?php if($errors->any()): ?>
    <div class="alert alert-danger" style="margin-top: 50px;">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
	<div class="well">
		<div class="row">
			<div class="col-md-6">
				<a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary pull-right"><i class="fa fa-plus-circle" aria-hidden="true"></i> New</a>
			</div>
			<div class="col-md-6"></div>
		</div>		
	</div>
	<div class="row">
		<div class="col-md-6 col-md-offset-1">
			<h2>Category List</h2>
			<div class="well">
				<table class="table table-responsive table-bordered">
					<thead>
						<tr>
							<th>#</th>
							<th>Category Name</th>
							<th></th>
						</tr>
					</thead>
					<tbody>
						<?php $i=0; ?>
						<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e(++$i); ?></td>
							<td><?php echo e($category->category_name); ?></td>
							<td>
								<?php echo Form::open(['route' => ['categories.destroy', $category->id], 'method' => 'DELETE', 'onsubmit' => 'return ConfirmDelete()']); ?>

									<a href="<?php echo e(route('categories.edit',$category->id)); ?>" class="btn btn-xs btn-primary"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
									<?php echo Form::submit("Delete", ['class' => 'btn btn-danger btn-xs pull-right']); ?>

								<?php echo Form::close(); ?>

								
							</td>

							
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>